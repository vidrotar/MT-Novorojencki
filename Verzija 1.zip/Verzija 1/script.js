  

var letnice = new Array();
var stevila = new Array();
// JQUERY
$(window).on("load", function (e) {
  var client = new $.es.Client({
      hosts: 'localhost:9200'
  });
  console.log("vrstica: 8: client: spremenljicka client je ustvarjena: " + client);
  client.ping({
    requestTimeout: 30000,
  }, function (error) {
    if (error) {
      console.error('vrstica: 13 elasticsearch cluster is down! | SLO: napaka cluster je down');
    } else {
      console.log('vrstica 15: All is well');
    }
  });
  

  // sPridobvi stevilo zapisov za nadaljno poizvedbo  
  var stzapisov;
  client.search({
    index: 'imena',
    type: 'vsa',
    body: {
      query: {
        match: {
          ime: "Aleks"
        }
      }
    }
  }).then(function (resp) {
      stzapisov     = resp['hits']['total'];
      console.log("stevilo zapisov: " + stzapisov);
  },
  function (err) {
      console.trace(err.message);
  }
  );
  // !Pridobi stevilo zapisov 
    

  //iskanje

  client.search(
    {
        index: 'imena',
        type: 'vsa',
        body: {
          size: 100 ,
          query: {
            match: {
              ime: "Aleks"
            }
          }
        }
      }).then(function (resp) {
              $a1 = resp['hits']['hits'][0]['_id'];
              $a2 = resp['hits']['hits'][0]['_score'];
              $a3 = resp['hits']['hits'][3]['_source'];
              for (i=0; i<stzapisov; i++){
                $a3 = resp['hits']['hits'][i]['_source'];
                console.log("Zapis: ime:" + $a3['ime'] + " leto:" + $a3['year'] + " stevilka:" + $a3['number'] + " rang:" + $a3['rang'] + " spol:" + $a3['spol']);
                $("ul").append("<li>Zapis " + i + " : ime:" + $a3['ime'] + " leto:" + $a3['year'] + " stevilka:" + $a3['number'] + " rang:" + $a3['rang'] + " spol:" + $a3['spol'] + " " + "</li>");
                letnice[i] = $a3['year'];
                stevila[i] = $a3['number'];
              }
      },
      function (err) {
          console.trace(err.message);
      }
    );
  //  !iskanje

});



// SE NE DELA
// $(window).on("keydown", function (e) {
//   //$("ul").append("<li> BLA</li>");
//   var width = 500;
//   var height = 500;
//   var margin = 25;
//   var axisLength = width - 2 * margin;
  
//   var bla = [];
//   var bla1 =[];
//   var bla2 =[];
//   for (var i = 0 ; i < letnice.length ; i++) {
//     if (i == letnice.length-1) {
//       bla.push("{x: " + letnice[i] + ", " + "y: " + stevila[i] + "}");
//       bla1.push(letnice[i]);
//       bla2.push(stevila[i]);

//       console.log("-" + i + "{x: " + letnice[i] + ", " + "y: " + stevila[i] + "}");
//     }
//     else
//     {
//       bla.push("{x: " + letnice[i] + ", " + "y: " + stevila[i] + "},");
//       console.log("-" + i + "{x: " + letnice[i] + ", " + "y: " + stevila[i] + "},"); 
//       bla1.push(letnice[i]);
//       bla2.push(stevila[i]);
 
//     }
    
//   }

//   var data1 = [
//           {x: 0, y: 4},
//           {x: 1, y: 9},
//           {x: 2, y: 6},
//           {x: 4, y: 5},
//           {x: 6, y: 7},
//           {x: 7, y: 3},
//           {x: 9, y: 2}
//   ];
//   var canvas = d3.select("body")
//                   .append("svg")
//                       .attr("width", width)
//                       .attr("height", height)
//                       .style("border", "1px solid");
                      
//   var widthScale = d3.scaleLinear()
//                       .domain([0, 10])
//                       .range([0, axisLength]);
  
//   var heightScale = d3.scaleLinear()
//                       .domain([10, 0])
//                       .range([0, axisLength]);
  
//   var xAxis = d3.axisBottom(widthScale);
  
//   canvas.append("g")
//       .attr("transform", function() { return "translate(" + margin + "," + (height - margin) + ")"; } )
//       .call(xAxis);
  
//   var line = d3.line()
//               .x(function(d) { return widthScale(d.x); })
//               .y(function(d) { return heightScale(d.y); })
//               .curve(d3.curveCardinal);
  
//   canvas.append("path")
//       .attr("d", line(data1))
//       .attr("fill", "none")
//       .attr("stroke", "red")
//       .attr("transform", function() { return "translate(" + margin + "," + margin + ")"; } );

// });

